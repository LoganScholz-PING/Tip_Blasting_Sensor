#include <Arduino.h>

void trigger0() {
}

void trigger1() {
}

void trigger2() {
}
